
#include "integrate.h"

Integrate::Integrate()
{}

void Integrate::execute()
{
	printf("execute: inside class Integrate\n");
}
