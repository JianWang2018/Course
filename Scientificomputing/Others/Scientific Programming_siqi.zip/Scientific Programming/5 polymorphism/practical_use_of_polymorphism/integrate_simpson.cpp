
#include "integrate_simpson.h"

void IntegrateSimpson::execute()
{
	printf("inside class IntegrateSimpson\n");
}
