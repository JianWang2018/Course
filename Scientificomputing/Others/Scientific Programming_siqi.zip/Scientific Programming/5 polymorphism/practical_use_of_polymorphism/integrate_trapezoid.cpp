
#include "integrate_trapezoid.h"

void IntegrateTrapezoid::execute()
{
	printf("inside class IntegrateTrapezoid\n");
}
