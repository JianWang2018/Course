
#ifndef _INTEGRATE_H_
#define _INTEGRATE_H_

#include <stdio.h>
#include "executable.h"

class Integrate : Executable
{
public:
	Integrate();
	void execute();
};

#endif
