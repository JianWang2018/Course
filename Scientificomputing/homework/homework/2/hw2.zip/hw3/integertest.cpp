#include <iostream>
#include <cstdlib>
#include "Integer.h"
 
using namespace std;
 
void displayInteger( char* str, Integer intObj )
 {
 cout << str << " is "<< intObj.getInteger() << endl;
 }
 
int main( int argc, char* argv[] )
{
 Integer intVal1;
 Integer intVal2(10);
 
 displayInteger( "intVal1", intVal1 );
 displayInteger( "intVal2", intVal2 );
  
 intVal1 = intVal2;
 displayInteger( "intVal1", intVal1 );

 Integer intVal3=intVal1;
 displayInteger( "intVal3", intVal3 );
 
 return EXIT_SUCCESS;
}
