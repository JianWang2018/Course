#include "Integer.h"

//Default constructor
Integer::Integer(void) 
{
 value=new int;
 *value = 0;
} 
 
Integer::Integer( int intVal )
{
  if (intVal) {
     value=new int;
     *value = intVal;
  } else
  {
     value=new int;
     *value=0;
  }
}
//Copy constructor 
Integer::Integer( const Integer& In)
{
     value=new int;
     value=In.value;             
}

//Destructor
Integer::~Integer(void)
{
  //delete value; // I think I should delete value when program  is ove, but why I can't delete here? If I put this code here, it will generate error message.
}

int Integer::getInteger() const
{
 return *value;
}
 
void Integer::setInteger( int newInteger )
{
 *value = newInteger;
}
 
Integer& Integer::operator=( const Integer& rhInt )
{
  if (this==&rhInt)
     return(*this);
     
  delete value;
  value=new int;
  value = rhInt.value;
  return (*this);
}
