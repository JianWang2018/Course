#ifndef INTEGER_H
#define INTEGER_H
 
class Integer
{
 public:
 Integer();
 Integer( int intVal );
 Integer(const Integer& In);
 
 int getInteger() const;
 void setInteger( int newInteger );
 Integer& operator=( const Integer& rhInteger );
  
 private:
 int *value; 
 ~Integer(void);
};
#endif 
