
#include "ArrayT.h"
#include <string.h> // for memcpy
#include <stdio.h>
//#include <typeinfo>
#include "GEtypes.h"
//#include "Vec3i.h"
#include <iostream>
using namespace std;

int main()
{
   cout<<"***************************************************************"<<endl;
   cout<<"*******************Question 1**********************************"<<endl;
   cout<<"***************************************************************"<<endl;
   cout<<""<<endl;
    float* temp1;
    float x[9] = {1,2,3,4,5,6,7,8,9};
    temp1=x;
    ArrayT <float> A(temp1, 3, 3, 1);

    ArrayT<float> subs(3,3,1); 
    const ArrayT<float>& b1=A*A;
    subs=b1;
    subs.print("b1");
    cout<<" 'const ArrayT<float>& b1=A*A' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& b2=b1*A;
    subs=b2;
    subs.print("b2");
    cout<<" 'const ArrayT<float>& b2=b1*A' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& b3=A*b1;
    subs=b3;
    subs.print("b3");
    cout<<" 'const ArrayT<float>& b3=A*b1' could work."<<endl;
    printf("\n\n\n");    


    ArrayT<float>& c1=A*A;
    subs=c1;
    subs.print("c1");
    cout<<" 'ArrayT<float>& c1=A*A' could work."<<endl;
    printf("\n\n\n");
    ArrayT<float>& c2=b1*A;
    subs=c2;
    subs.print("c2");
    cout<<" 'ArrayT<float>& c2=b1*A;' could work."<<endl;
    printf("\n\n\n");
    ArrayT<float>& c3=A*b1;
    subs=c3;
    subs.print("c3");
    cout<<" 'ArrayT<float>& c3=A*b1' could work."<<endl;
    printf("\n\n\n");  

    double num1=2.0;
    double num2=3.0;
    const ArrayT<float> d1=num1*A*A;
    subs=d1;
    subs.print("d1");
    cout<<" 'const ArrayT<float> d1=2.0*A*A' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float> d2=num2*b1*A;
    subs=d2;
    subs.print("d2");
    cout<<" 'const ArrayT<float> d2=3.0*b1*A' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float> d3=A*b1;
    subs=d3;
    subs.print("d3");
    cout<<" 'const ArrayT<float> d3=A*b1' could work."<<endl;
    printf("\n\n\n"); 


    const ArrayT<float>& e1=num2*d1*A*b1;
    subs=e1;
    subs.print("e1");
    cout<<" 'const ArrayT<float>& e1=3.*d1*A*b1' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& e2=num1*c1*A*b1;
    subs=e2;
    subs.print("e2");
    cout<<" 'const ArrayT<float>& e2=2.*c1*A*b1' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& e3=A*c1*b1;
    subs=e3;
    subs.print("e3");
    cout<<" 'const ArrayT<float>& e3=A*c1*b1' could work."<<endl;
    printf("\n\n\n"); 


    const ArrayT<float>& f1=d1*A*b1;
    subs=f1;
    subs.print("f1");
    cout<<" 'const ArrayT<float>& f1=d1*A*b1' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& c4=d1*A*b1;
    subs=c4;
    subs.print("c4");
    cout<<" 'const ArrayT<float>& c4=d1*A*b1' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& c5=A*d1*b1;
    subs=c5;
    subs.print("c5");
    cout<<" 'const ArrayT<float>& c5=A*d1*b1' could work."<<endl;
    printf("\n\n\n"); 

    const ArrayT<float>& ff1=d1*A+b1*b3*e2+num2*c4;
    subs=ff1;
    subs.print("ff1");
    cout<<" 'const ArrayT<float>& ff1=d1*A+b1*b3*e2+3.*c4' could work."<<endl;
    printf("\n\n\n");
    const ArrayT<float>& f2=num1*A*A;
    subs=f2;
    subs.print("f2");
    cout<<" 'const ArrayT<float>& f2=2.*A*A' could work."<<endl;
    printf("\n\n\n");
 

//Question 2
   cout<<"***************************************************************"<<endl;
   cout<<"*******************Question 2**********************************"<<endl;
   cout<<"***************************************************************"<<endl;
   cout<<""<<endl;
    float a[27];
    float b[3];
    for (int i=0; i<3; i++) {
       for (int j=0; j<3; j++) {
           a[i*3+j]=100*i+j;
           b[i]=(float)i;
       }
    }
    temp1=a;
    ArrayT <float> A2(temp1, 3, 3, 3);

    ArrayT<float>& C=b*A2;
    subs=C;
    subs.print("C");
    cout<<" 'ArrayT<float>& C=b*A2' could work."<<endl;
    printf("\n\n\n");
 
    ArrayT<float>& D=A2*b;
    subs=D;
    subs.print("D");
    cout<<" 'ArrayT<float>& D=A2*b' could work."<<endl;
    printf("\n\n\n");

    ArrayT<float>& E=b*A2+A2*b;
    subs=E;
    subs.print("E");
    cout<<" 'ArrayT<float>& E=b*A2+A2*b' could work."<<endl;
    printf("\n\n\n");

    const ArrayT<float>& E2=b*A2+A2*b;
    subs=E2;
    subs.print("E2");
    cout<<" 'const ArrayT<float>& E2=b*A2+A2*b' could work."<<endl;
    printf("\n\n\n");

    const ArrayT<float>& F=A2*b;
    subs=F;
    subs.print("F");
    cout<<" 'const ArrayT<float>& F=A2*b' could work."<<endl;
    printf("\n\n\n");

    const ArrayT<float> G=b*A2+A2*b;
    subs=G;
    subs.print("G");
    cout<<" 'const ArrayT<float> G=b*A2+A2*b' could work."<<endl;
    printf("\n\n\n");

    const ArrayT<float> H=A2*b;
    subs=H;
    subs.print("H");
    cout<<" 'const ArrayT<float> H=A2*b' could work."<<endl;
    printf("\n\n\n");

}
