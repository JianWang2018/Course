#ifndef _GE_TYPES_H_
#define _GE_TYPES_H_

//typedef double GE_FLOAT;
typedef float GE_FLOAT;

#endif
