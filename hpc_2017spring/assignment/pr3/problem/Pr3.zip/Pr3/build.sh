#!/bin/bash

module load intel-openmpi
module load tau

make
