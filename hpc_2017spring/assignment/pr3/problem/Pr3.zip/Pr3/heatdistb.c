/*
 *	heatdistb.c
 *
 *	Simple heat distribution computation on 2D grid
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <mpi.h>

#define MAXSTEP 2000
#define MAXSIZE (240+2)

#define TOLERANCE 0.05

const char grayscale10[11] = " .:-=+*#%@$";

/* Jacobi iteration */
static int update(float *hp, int p, int P, int n, int m, int t);

int main(int argc, char *argv[])
{
  int p, P;
  int n, m, k;
  int i, j, t;
  float *hp;
  double t0, tf;

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &p);
  MPI_Comm_size(MPI_COMM_WORLD, &P);

  n = MAXSIZE;
  m = (n-2)/P+2;
  hp = malloc(sizeof(float)*n*m);

  /* Apply heat source to the left boundary */
  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      if (j == 0)
        hp[n*i+j] = 10;
      else
        hp[n*i+j] = 0;

  MPI_Barrier(MPI_COMM_WORLD);

  t0 = MPI_Wtime();

  for (t = 1; t <= MAXSTEP; t++)
    if (update(hp, p, P, n, m, t))
      break;

  tf = MPI_Wtime();

  if (p == 0)
    printf("P = %d\nIterations = %d\nTime = %gs\nTolerance = %g\n", P, t, tf-t0, (float)TOLERANCE);

  /* TODO: dump entire grid by letting each processor dump in turn */

  if (p == 0)
  {
    k = n;
    if (k > 122)
      k = 122;
    for (i = 1; i < m-1; i++)
    { for (j = 1; j < k-1; j++)
	printf("%c", grayscale10[(int)(hp[n*i+j]+0.5)]);
      printf("\n");
    }
    fflush(stdout);
    usleep(100);
  }

  MPI_Barrier(MPI_COMM_WORLD);

  free(hp);

  MPI_Finalize();

  return 0;
}

/* Jacobi iteration with overlapped computation/communication
   hp: 2D grid (in/out)
   p:  processor rank (in)
   P:  number of processors (in)
   n:  nxn grid size (+2 boundary cells) (in)
   m:  local grid height m=(n-2)/P+2
   t:  iteration count
*/
static int update(float *hp, int p, int P, int n, int m, int t)
{
  int i, j;
  int stop = 0;
  static float *hnew = NULL;	/* static keeps value accross calls */
  static int hnew_size = 0;
  MPI_Status status;
  
  /* Trick to allocate only when needed.
     Note 1: static *hnew keeps value across calls so we can reuse its space!
     Note 2: that this is not MT-safe and not recommended in general!
  */
  if (hnew_size != n*m)
  {
    if (hnew)
      free(hnew);
    hnew = malloc(sizeof(float)*n*m);
    hnew_size = n*m;
  }

  if (p > 0 && p < P-1)
  {
    MPI_Sendrecv(&hp[n*(m-2)], n, MPI_FLOAT, p+1, 0,
                 &hp[n*0],     n, MPI_FLOAT, p-1, 0, MPI_COMM_WORLD, &status);
    MPI_Sendrecv(&hp[n*1],     n, MPI_FLOAT, p-1, 1,
                 &hp[n*(m-1)], n, MPI_FLOAT, p+1, 1, MPI_COMM_WORLD, &status);
  }
  else if (p == 0 && p < P-1)
    MPI_Sendrecv(&hp[n*(m-2)], n, MPI_FLOAT, p+1, 0,
                 &hp[n*(m-1)], n, MPI_FLOAT, p+1, 1, MPI_COMM_WORLD, &status);
  else if (p > 0 && p == P-1)
    MPI_Sendrecv(&hp[n*1],     n, MPI_FLOAT, p-1, 1,
                 &hp[n*0],     n, MPI_FLOAT, p-1, 0, MPI_COMM_WORLD, &status);
  
  for (i = 1; i < m-1; i++)
    for (j = 1; j < n-1; j++)
      hnew[n*i+j] = 0.25f*(hp[n*(i-1)+j]+hp[n*(i+1)+j]+hp[n*i+j-1]+hp[n*i+j+1]);

  /* TODO: Check convergence every 100 iterations (Pacheco) */
  /* NOT IMPLEMENTED: set stop = 1 to terminate */

  /* Copy new */
  for (i = 1; i < m-1; i++)
    for (j = 1; j < n-1; j++)
      hp[n*i+j] = hnew[n*i+j];

  return stop;
}
