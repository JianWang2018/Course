#!/bin/bash -login
#SBATCH --job-name="heatdistb"
#SBATCH -n 8
#SBATCH -p backfill
#SBATCH --mail-type="ALL"
#SBATCH -t 00:01:00

echo $SLURM_JOB_NODELIST
module purge
module load intel-openmpi
module load tau
export TAU_COMM_MATRIX=1
srun -n 4 ./heatdistb
