#!/bin/bash

tau_treemerge.pl
tau2slog2 tau.trc tau.edf -o tautrace.slog2
jumpshot tautrace.slog2 &
