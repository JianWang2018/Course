#include "sim_driver.h"

static void deleteflow(int node, int edge, int index)
{
  struct linkedlist *tmp, *tmp1;

  tmp = flowlisthead[node][edge];
  if (tmp->val == index) {
    if (flowlisthead[node][edge] == flowlisttail[node][edge]) {
      free(tmp);
      flowlisttail[node][edge] = flowlisthead[node][edge] = NULL;
    } else {
      flowlisthead[node][edge] = tmp->next;
      free(tmp);
    }
  } else {
    tmp1=tmp->next;
    while ((tmp1 != NULL) && (tmp1->val != index)) {
      tmp = tmp1; tmp1 = tmp->next;
    }
    
    if (tmp1 == flowlisttail[node][edge]) {
      tmp->next = tmp1->next;
      free(tmp1);
      flowlisttail[node][edge] = tmp;
    } else {
      tmp->next = tmp1->next;
      free(tmp1);
    }
  }
}

void identifyflow(int src, int port) 
{
  struct linkedlist *tmp;

  tmp = flowlisthead[src][port];
  while (tmp != NULL) {
    if (flag[tmp->val] == 0) {
      affectedflow[flow_counter++] = tmp->val;
      flag[tmp->val] = 1; 
    }
    tmp = tmp->next;
  }
}

void moveflow(long long cur_time)
{
  int i, j;

  for (i=0; i<flow_counter; i++) {
    j = affectedflow[i];
    if ((end[j] <0)) {
      remsize[j] = remsize[j] - (long long)(((double)rate[j]/1000000000) * (cur_time - modtime[j]));
      modtime[j] = cur_time;
    }
  }
}

void resetflag()
{
  int i;
  for (i=0; i<flow_counter; i++)
    flag[affectedflow[i]] = 0;

  flow_counter = 0;
}

void calculateflow()
{

  int i, j, k;
  long long minrate, mintime;
  int tmp_path;

  for (i=0; i<flow_counter; i++) {
    j = affectedflow[i];
    if ((end[j] <0)) {
      minrate = INFINITY;
      
      for (k=1, tmp_path= flowpath[j][0]; flowpath[j][k] != -1; k++) {
	if (curbw[tmp_path][flowpath[j][k]] < minrate) {
	  minrate = curbw[tmp_path][flowpath[j][k]];
	}
        tmp_path = graph[tmp_path][flowpath[j][k]];
      }
      rate[j] = minrate;
      tmpend[j] = modtime[j] + (long long) ((remsize[j] / (double)rate[j])*1000000000) + 1;
      
    }
  }

  mintime = INFINITY;

  for (i=flowhead; i<flowtail; i++) {
    if (end[i] >=0) continue;
    if (tmpend[i] < mintime) 
      mintime = tmpend[i];
  }

  next_network_time = mintime;
}


void timeforward(long long t) 
{
  int j, k;
  int tmp_path;
  int path[MAX_PATH_LEN];

  if (t<next_network_time) return;

  while (next_network_time <= t) {
    for (j=flowhead; j<flowtail; j++) {
      if ((end[j] < 0) && (tmpend[j] <= next_network_time)) {
        remsize[j] = 0;
        end[j] = next_network_time;

	for (k=0; k<MAX_PATH_LEN;k++) path[k] = flowpath[j][k];
	for (k=1, tmp_path = path[0]; path[k] != -1; k++) {
	
	  load_graph[tmp_path][path[k]]--;
	  if (load_graph[tmp_path][path[k]] > 0) {
	    curbw[tmp_path][path[k]] = bandwidth[tmp_path][path[k]] / load_graph[tmp_path][path[k]];
	  }
	  deleteflow(tmp_path, path[k], j);
	  identifyflow(tmp_path, path[k]);
	  
	  tmp_path = graph[tmp_path][path[k]];
	}
      }
    }
    
    while ((end[flowhead] > 0) && (flowhead != flowtail)) 
      flowhead++;     

    moveflow(next_network_time);
    calculateflow();
    resetflag();
  }
}

void addflow(unsigned short new_src,  unsigned short new_dest, unsigned int new_size, long long new_time)
{
  int k, m;
  int path[MAX_PATH_LEN];
  
  src[flowtail] = new_src;
  dst[flowtail] = new_dest;
  size[flowtail] = new_size;
  remsize[flowtail] = new_size;
  start[flowtail] = new_time;
  end[flowtail] = -1;
  modtime[flowtail] = new_time;

  if (new_src == new_dest) {  
    end[flowtail] = new_time;
    flowtail++;
    return;
  }

  torus_dimorder_routing(new_src, new_dest, path);

  pathlen[flowtail] = 0;
  for (k=2; path[k] != -1; k++) 
    pathlen[flowtail]++;

  for (k=0; k<MAX_PATH_LEN; k++) 
    flowpath[flowtail][k] = path[k];

  for (k=0; path[k+1] != -1; k++) {
    for (m=0; (graph[path[k]][m] != -1) && (graph[path[k]][m] != path[k+1]); m++);
    
    flowpath[flowtail][k+1] = m;
    struct linkedlist *tmp;
    tmp = (struct linkedlist *)malloc(sizeof (struct linkedlist));
    tmp->val = flowtail;
    tmp->next = NULL;

    if (flowlisttail[path[k]][m] == NULL) {
      flowlisttail[path[k]][m] = flowlisthead[path[k]][m] = tmp;
    } else {
      flowlisttail[path[k]][m]->next = tmp;
      flowlisttail[path[k]][m] = tmp;
    }
    load_graph[path[k]][m] ++;
    identifyflow(path[k], m);

    curbw[path[k]][m] = bandwidth[path[k]][m] / load_graph[path[k]][m];
  }   

  flowtail++;
  network_time = new_time;
  moveflow(new_time);
}

void event_dispatcher(char *input, char *output)
{
  FILE *input_file, *output_file;
  int input_src, input_dest, input_size, i;
  long long input_time;
  long long int tmp_time, t;  


  if ((input_file = fopen(input, "r")) == NULL) {
    printf("error opening file %s for read.\n", input);
    exit(0);
  }

  if ((output_file = fopen(output, "w")) == NULL) {
    printf("error opening file %s for write.\n", output);
    exit(0);
  }

  fscanf(input_file, "%d %d %d %lld", &input_src, &input_dest, &input_size, &input_time);

  while ((input_src != -1) || (flowhead != flowtail)) {

    tmp_time = next_network_time;
    if ((input_src != -1) && (tmp_time > input_time)) {
      t = input_time;
      while(t == input_time) {
	addflow(input_src, input_dest, input_size, input_time);
	fscanf(input_file, "%d %d %d %lld", &input_src, &input_dest, &input_size, &input_time);
      } 
      calculateflow(input_time);
      resetflag();
    } else
      timeforward(tmp_time);
  }
  
  for(i=0;i<flowhead;i++)
    fprintf(output_file, "%d %d %d %lld %lld\n", src[i], dst[i], size[i], start[i], end[i]);
  
  fflush(0);
  fclose(input_file);
  fclose(output_file);
}

int main(int argc, char *argv[]) 
{

  int i;
  if (argc < 6) {
    printf("  ./a.out torus Num_Dimension Num_Terminals_Per_Switch \
    a1 a2 ... an bw0 bw1 bw2... bwn DIMORDER\n");
    exit(0);
  }
 if (strcmp(argv[1], "torus") == 0){
    if( torus_read_input(argc, argv) != 0 )exit(0);
    nprocs = totPE;
    event_dispatcher("d1", "myoutput");
  }else{
    printf("Error : Topology is not supported.\n\n");
    printf("Currently supported topologies are:\n");
    printf("Torus Topology : torus\n");
    exit(0);
  }
			     
  return 0;
}
