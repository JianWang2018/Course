#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "topology.h"

/* Global variables for torus */
int torus_N;         // The dimension of the torus
int torus_T;         // The number of terminals connected to each switch
long long int torus_BW[TORUS_MAX_DIM+1];
int torus_ARITY[ TORUS_MAX_DIM ];
/* end */

/** Function prototypes for torus **/

void torus_xor_node_label
(int xor_label[TORUS_MAX_DIM+1], int src_label[TORUS_MAX_DIM+1],int dst_label[TORUS_MAX_DIM+1]);
int torus_xor(int x, int y);
void torus_compute_direction_vector_torus
(int dir_label[TORUS_MAX_DIM+1], int src_label[TORUS_MAX_DIM+1], int dst_label[TORUS_MAX_DIM+1] );
void torus_flip_label(int *p);
int  torus_compute_nodeid( int label[TORUS_MAX_DIM+1] );
void torus_compute_label(int nodeid, int label[TORUS_MAX_DIM+1]);
void torus_print_label(int label[TORUS_MAX_DIM+1]);
void torus_copy_label(int *dst, int *src);
/** Function prototypes for torus ends **/

/*
Input 
int dimension,
int arity[ dimension ],
int bandwidth[ dimension + 1 ]
int routing
*/
void torus_topology_init( int dim, int t, int *a, long long int *bw, int r ) {
  int i;
  
  if( TORUS_MAX_DIM < dim ){
    printf("Maximum supported dimension for Torus is %d.\
    Requested dimension is %d\n", TORUS_MAX_DIM, dim);
    exit(0);
  }
  
  torus_N = dim;
  torus_T = t;
  
  for(i=0; i< torus_N; i++)     torus_ARITY[i] = a[i];
  for(i=0; i< torus_N + 1; i++) torus_BW[i]    = bw[i];
  
  torus_build_topology( torus_N );
  
  printf("Simulating TORUS with parameters:\n");
  printf("Dimension : %d,\n", torus_N);
  
  for(i=0; i< torus_N; i++)printf("Arity[%d] = %d\n",i,torus_ARITY[i]);
  for(i=0; i< torus_N+1; i++)printf("BW[%d] = %lld\n",i,torus_BW[i]);
  
  printf("Number PE = %d, SE = %d, Total = %d\n", totPE, totSE, totNode);
  
  routing  = r;
  
  if (r == TORUS_DIMENSIONORDER_ROUTING) {
    routing_algorithm = torus_routing_algorithm = torus_dimorder_routing;
    model_routing_algorithm = torus_model_routing_algorithm = torus_model_dimorder_routing;
    routingType = SINGLEPATH;
    printf("Routing algorithm: Dimension Order routing\n");
  } else if (r == TORUS_LOCALADAPTIVE_ROUTING) {
    routing_algorithm = torus_routing_algorithm = torus_localadaptive_routing;
    routingType = SINGLEPATH;
    printf("Routing algorithm: Local Adaptive routing\n");
  } else {
    printf("Routing scheme %d not supported on torus.\n", routing);
    exit(0);
  }

  if (DEBUG_LEVEL > 0) {
    torus_print_topology();
  }  
}

void torus_update_load(int *path)
{
  int i,j;
  for(i=0; i < MAX_PATH_LEN; i++){
    if( path[i+1] != -1 ){
      for(j=0; graph[path[i]][j] != -1; j++){
        if(graph[path[i]][j] == path[i+1]){
          load_graph[path[i]][j]++;
        }
      }
    }
    else break;
  }
}

void torus_print_load()
{
  int i,j;
  for(i=0; i< totNode; i++){
    for(j=0; graph[i][j] != -1; j++)
#ifdef _VLB_ROUTING
      printf("load_graph[%d][%d]=%g\n",i,graph[i][j],load_graph[i][j]);
#else
      printf("load_graph[%d][%d]=%d\n",i,graph[i][j],load_graph[i][j]);
#endif
    printf("\n\n");
  }
}

void torus_copy_label(int *dst, int *src) 
{
  int i;
  for (i=0; i<=torus_N; i++) {
    dst[i] = src[i];
  }
}

void torus_print_label(int label[TORUS_MAX_DIM+1])
{
  int i;
  printf("(");
  for (i=0; i< torus_N-1; i++) printf("%d, ", label[i]);
  printf("%d)", label[i]);
}

void torus_compute_label(int nodeid, int label[TORUS_MAX_DIM+1])
{
  int i;
  for(i = 0; i <= TORUS_MAX_DIM; i++ ) label[i] = -1;
  i = 0;
  if( nodeid < totSE ){
    while(i < torus_N ){
      label[torus_N-i-1] = nodeid % torus_ARITY[i];
      nodeid = nodeid / torus_ARITY[i];
      i++;
    }
  }  
}

int torus_compute_nodeid( int label[TORUS_MAX_DIM+1] )
{
  /*
  int i,j;
  int nodeid = 0;
  int prod = 1;
  
  //print_label_torus( label );
  
  for(i=0; i < torus_N ; i++){
    prod = 1;
    for(j = 1; j < (torus_N-i) ; j++) prod *= ARITY[j-1];
    nodeid += label[i]*prod;
  }
  
  //printf("Computed Nodeid = %d\n", nodeid);
  return nodeid;
  */
  
  int nodeid = label[0], i;
  for(i=1; i < torus_N ; i++){
    nodeid = nodeid * torus_ARITY[torus_N-i-1] + label[i];
  }
  return nodeid;
  
}

void torus_print_topology()
{
  int i, j, k;
  int label[TORUS_MAX_DIM+1];
  printf("Torus Topology.\n");
  printf("Number PE = %d, SE = %d, Total = %d\n", totPE, totSE, totNode);

  for (i=0; i<totNode; i++) {
    if(i < totPE)
      printf("Terminal Node %d, ", i);
    else{
      torus_compute_label(i-totPE, label);
      printf("Switch Node %d [%d], ", i, (i-totPE));
      torus_print_label(label);
    }
    printf(", connects to\n");
    for (j=0; graph[i][j] != -1; j++) {
      k = graph[i][j];
      if( k < totPE )
        printf("  Terminal node %d (bw=%lld), ", k, bandwidth[i][j]);
      else{
        printf("  Switch node %d [%d] (bw=%lld), ",k,k-totPE,bandwidth[i][j]);
        torus_compute_label(k-totPE, label);
        torus_print_label(label);
      }
      printf("\n");
    }
  }
}

void torus_build_topology( int n )
{
  int i,j,k;
  int graphindex;
  int label[TORUS_MAX_DIM+1];
  int code[TORUS_MAX_DIM+1];

  // Compute the number of terminals, switches, nodes
  totSE = 1;
  for(i=0; i < torus_N; i++) totSE *= torus_ARITY[i];
  totPE = totSE * torus_T;
  totNode = totSE + totPE;

  for (i=0; i<totNode; i++) 
    for (j=0; j< MAX_DEGREE; j++) {
      graph[i][j] = -1;
    }

  // Establish the connectivity from the terminals to the switches
  for(i=0; i < totPE; i++){
    graph[i][0] = totPE + i / torus_T;
    bandwidth[i][0] = torus_BW[0];
  }

  // Establish the connectivity from the switches to other nodes
  for (i=0; i< totSE; i++) {
    torus_compute_label(i, label);
    graphindex = totPE + i;
    // Establish the connectivity with other switches
    for (j=0; j< torus_N; j++) {
      k = torus_N-j-1;
      torus_copy_label(code, label);
      code[k] = (code[k]+1) % torus_ARITY[j];
      graph[graphindex][j] = totPE + torus_compute_nodeid(code);
      bandwidth[graphindex][j] = torus_BW[j+1];
    }
    for (j=0; j< torus_N; j++) {
      k = torus_N-j-1;
      torus_copy_label(code, label);
      code[k] = (code[k]-1 + torus_ARITY[j]) % torus_ARITY[j];
      //nodeid = torus_compute_nodeid(code);
      graph[graphindex][torus_N+j] = totPE + torus_compute_nodeid(code);
      bandwidth[graphindex][torus_N+j] = torus_BW[j+1];
    }

    // Establish the connectivity with other terminals/processing elements
    for(j=0; j < torus_T; j++){
      graph[graphindex][2*torus_N+j] = i*torus_T + j;
      bandwidth[graphindex][2*torus_N+j] = torus_BW[0];
    }
  }

  //print_torus();
}

void torus_print_path(int *path)
{
  int i = 0, j;
  int label[TORUS_MAX_DIM+1];
  while (path[i] != -1) {
    if(path[i] < totPE){
      printf("Terminal node %d, ", path[i]);
    }
    else{
      j = path[i] - totPE;
      torus_compute_label(j, label);
      printf("Switch node %d [%d], ", path[i], j);
      torus_print_label(label);
    }
    printf("\n");
    i++;
  }
}

void torus_flip_label(int *p)
{
  if(*p == 1) *p = 0;
  else *p = 1;
}

void torus_compute_direction_vector
(int dir_label[TORUS_MAX_DIM+1], int src_label[TORUS_MAX_DIM+1], int dst_label[TORUS_MAX_DIM+1] )
{
  int i, m, a, d, j;
  for(i=0; i< TORUS_MAX_DIM+1; i++) dir_label[i] = -5;
  for(i=0; i< torus_N; i++){
    j = torus_N - i - 1;
    //printf("src_label[%d] = %d, dst_label[%d] = %d Arity = %d",
    //       i,src_label[j], i, dst_label[j], ARITY[i]);
    //if( dst_label[j] != src_label[j]){
      a = torus_ARITY[i];
      m = ( dst_label[j] - src_label[j] + a ) % a;
      if( m <= a/2 ) d = m;
      else d = m - a;
      //printf("Computed m=%d d=%d\n",m,d);
      if(d == a/2)   dir_label[j] = 0;
      else if(d < 0) dir_label[j] = -1;
      else if(d > 0) dir_label[j] = 1;
    //}
  }
  //printf("(");
  //for(i=0; i< torus_N; i++){
  //  printf("%d,",dir_label[i]);
  //}
  //printf(")\n");
}

int torus_xor(int x, int y){
  if( x == y ) return 0;
  else return 1;
}

void torus_xor_node_label
(int xor_label[TORUS_MAX_DIM+1], int src_label[TORUS_MAX_DIM+1],int dst_label[TORUS_MAX_DIM+1])
{
  int i;
  for(i=0; i < torus_N; i++) 
    xor_label[i] = torus_xor( src_label[i], dst_label[i] );
}

void torus_localadaptive_routing(int src, int dst, int *path)
{
  int srcswitch, dstswitch;
  int src_label[TORUS_MAX_DIM+1];
  int dst_label[TORUS_MAX_DIM+1];
  int dir_label[TORUS_MAX_DIM+1];
  int i, j, k, l, hop = 1;
  int smallest_a[MAX_DEGREE+1];
  int smallest;
  int s_c;
  
  if( (src >= totPE)||(src < 0 )||(dst >= totPE)||(dst < 0) ){
    printf("Either Src %d or Dst %d or both not processing nodes.\n",src,dst);
    exit(0);
  }

  srcswitch = graph[src][0] - totPE;
  dstswitch = graph[dst][0] - totPE;

  torus_compute_label(dstswitch, dst_label);
    
  if (src == dst){
    path[0] = src;
    path[1] = -1;
    return;
  }
  else if( srcswitch == dstswitch ){
    path[0] = src;
    path[1] = srcswitch + totPE;
    path[2] = dst;
    path[3] = -1;
    return;
  }
  else{
    for(i=0; i < MAX_PATH_LEN ; i++) path[i] = -1;
    path[0] = src;
    path[1] = srcswitch + totPE;
    
    while(srcswitch != dstswitch ){
      torus_compute_label(srcswitch, src_label);

      torus_compute_direction_vector(dir_label, src_label, dst_label);
            
      smallest = 1000000;

      for(j=0; j < torus_N; j++){
        k = torus_N-j-1;

        if( dir_label[k] == -1 ){
          l = j + torus_N;
          if( load_graph[ path[ hop ] ][ l ] < smallest) 
            smallest = load_graph[ path[ hop ] ][ l ];
        }
        else if( dir_label[k] == 1){
          l = j;
          if( load_graph[ path[ hop ] ][ l ] < smallest) 
            smallest = load_graph[ path[ hop ] ][ l ];
        }
        else if( dir_label[k] == 0){
          l = j;
          if( load_graph[ path[ hop ] ][ l ] < smallest) 
            smallest = load_graph[ path[ hop ] ][ l ];
          l = j + torus_N;
          if( load_graph[ path[ hop ] ][ l ] < smallest) 
            smallest = load_graph[ path[ hop ] ][ l ];
        }
      }
      
      s_c = 0;
      for(j=0; j < torus_N; j++){
        k = torus_N-j-1;
        
        if( dir_label[k] == -1 ){
          l = j + torus_N;
          if( load_graph[ path[ hop ] ][ l ] == smallest){
            smallest_a[ s_c ] = l;
            s_c++;
          }
        }
        else if( dir_label[k] == 1 ){
          l = j;
          if( load_graph[ path[ hop ] ][ l ] == smallest){
            smallest_a[ s_c ] = l;
            s_c++;
          }
        }
        else if( dir_label[k] == 0 ){
          l = j;
          if( load_graph[ path[ hop ] ][ l ] == smallest){
            smallest_a[ s_c ] = l;
            s_c++;
          }
          l = j + torus_N;
          if( load_graph[ path[ hop ] ][ l ] == smallest){
            smallest_a[ s_c ] = l;
            s_c++;
          }
        }
      }

      j = smallest_a[ rand() % s_c ];

      srcswitch = graph[ path[ hop ] ][ j ];
      path[++hop] = srcswitch;
      srcswitch -= totPE;
    }
    path[++hop] = dst;
  }
  
  //torus_print_path(path);
}

void torus_model_dimorder_routing(int src, int dst, int *len, int *rsrc, int *rdst)
{
  int path[MAX_PATH_LEN];
  int i;

  torus_dimorder_routing(src, dst, path);
  for (i=0; path[i+1] != -1; i++) {
    rsrc[i] = path[i];
    rdst[i] = path[i+1];
  }
  *len = i;
}


void torus_dimorder_routing(int src, int dst, int *path)
{
  int srcswitch, dstswitch;
  int src_label[TORUS_MAX_DIM+1];
  int dst_label[TORUS_MAX_DIM+1];
  int dir_label[TORUS_MAX_DIM+1];
  int i, j, hop = 0, dim = 0, a;
  
  if( (src < 0)||(src >= totPE )||(dst < 0)||(dst >= totPE) ){
    printf("Either Src %d or Dst %d or both not processing nodes.\n",src,dst);
    exit(0);
  }

  srcswitch = graph[src][0] - totPE;
  dstswitch = graph[dst][0] - totPE;

  torus_compute_label(srcswitch, src_label);
  torus_compute_label(dstswitch, dst_label);

  if (src == dst){
    path[0] = src;
    path[1] = -1;
    return;
  }
  else if( srcswitch == dstswitch ){
    path[0] = src;
    path[1] = srcswitch + totPE;
    path[2] = dst;
    path[3] = -1;
    return;
  }
  else{
    torus_compute_direction_vector(dir_label, src_label, dst_label);
    for(i=0; i < MAX_PATH_LEN ; i++) path[i] = -1;
    path[hop++] = src;
    path[hop++] = srcswitch + totPE;
    while(1){
      j = torus_N - dim - 1;
      if( src_label[j] == dst_label[j] ) dim++;
      else{
        a = torus_ARITY[dim];
        if( dir_label[j] != 0 )
          src_label[j] = (src_label[j]+dir_label[j]+a)%a;
        else{
          if(srcswitch % 2 == 0)
            src_label[j] = ( src_label[j] + 1 ) % a;
          else
            src_label[j] = ( src_label[j] -1 + a ) % a;
        }
        path[hop++] = totPE + torus_compute_nodeid( src_label );
      }

      if( dim >= torus_N ) break;
    }
    path[hop++] = dst;
  }
}

int torus_read_input(int argc, char *argv[]){
  int i, n, t, r;
  int arity[TORUS_MAX_DIM];
  long long int bw[TORUS_MAX_DIM + 1];
  
  if (argc < 3 ) {
    printf("Usage: %s torus Num_Dimension Num_Terminals_Per_Switch \
    a1 a2 ... an bw0 bw1 bw2... bwn routing traffic_file\n", argv[0]);
    return -1;
  }
  
  n = atoi( argv[2] );        // capture the dimension
  
  if (argc < 2*n+5) {
    printf("Usage: %s torus Num_Dimension Num_Terminals_Per_Switch \
    a1 a2 ... an bw0 bw1 bw2... bwn routing\n", argv[0]);
    return -1;
  }
  
  t = atoi( argv[3] );        // capture the number of terminals per switch
    
  for(i=0; i < n; i++) arity[i] = atoi( argv[4+i] );
  for(i=0; i < n+1; i++) bw[i] = atoi( argv[n+4+i] ) * ((long long int)1000000);
    
  if (strcmp(argv[5+2*n], "DIMORDER") == 0) {
    r = TORUS_DIMENSIONORDER_ROUTING;
  }
  else if (strcmp(argv[5+2*n], "ADAPTIVE") == 0) {
    r = TORUS_LOCALADAPTIVE_ROUTING;
  }
  else{
    printf("Routing scheme %s not supported: Options are\
    DIMORDER or ADAPTIVE\n",argv[5+2*n]);
    return -1;
  }
  
  if (r != TORUS_DIMENSIONORDER_ROUTING) {
    printf("Modeling of torus only supports dimension order routing.\n");
    printf("%s not supported.\n", argv[5+2*n]);
    exit(0);
  }
    
  torus_topology_init(n, t, arity, bw, r);
  //torus_print_topology();
  
  return 0;  
}
