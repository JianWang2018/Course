#ifndef TORUS_H
#define TORUS_H
#include "topology.h"

// Routing schemes for the Torus
// Use block 61 through 80

#define TORUS_DIMENSIONORDER_ROUTING 61
#define TORUS_LOCALADAPTIVE_ROUTING  62

void torus_build_topology( int n );
void torus_localadaptive_routing(int src, int dst, int *path);
void torus_dimorder_routing(int src, int dst, int *path);
void (* torus_routing_algorithm)(int src, int dst, int *path);

void torus_model_dimorder_routing(int src, int dst, int *len, int *rsrc, int *rdst);
void (* torus_model_routing_algorithm)(int src, int dst, int *len, int *rsrc, int *rdst);

void torus_topology_init( int dim, int n, int *a, long long int *bw, int r );
void torus_print_topology();
int torus_read_input(int argc, char *argv[]);

void torus_print_path(int *path);
void torus_update_load(int *path);
void torus_print_load();


#define TORUS_MAX_DIM 16
/* extern Global variables for torus */
extern int torus_N;         // The dimension of the torus
extern int torus_T;         // The number of terminals connected to each switch
extern long long int torus_BW[TORUS_MAX_DIM+1];
extern int torus_ARITY[ TORUS_MAX_DIM ];

#endif
