#ifndef SIM_DRIVER_H
#define SIM_DRIVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "topology_var.h"

#define INFINITY 999999999999
#define FLOW_COUNT 100000

unsigned short src[FLOW_COUNT], dst[FLOW_COUNT];
long long flowhead, flowtail = 0;
long long start[FLOW_COUNT], end[FLOW_COUNT], tmpend[FLOW_COUNT], modtime[FLOW_COUNT];
int size[FLOW_COUNT], remsize[FLOW_COUNT];
short int pathlen[FLOW_COUNT];
char flag[FLOW_COUNT];
long long rate[FLOW_COUNT], curbw[MAX_NODE][MAX_DEGREE];
short int flowpath[FLOW_COUNT][MAX_PATH_LEN];
int affectedflow[FLOW_COUNT * MAX_PATH_LEN+1];
long long network_time = 0;
long long next_network_time = INFINITY;
struct linkedlist {
  int val;
  struct linkedlist *next;
};
struct linkedlist *flowlisthead[MAX_NODE][MAX_DEGREE];
struct linkedlist *flowlisttail[MAX_NODE][MAX_DEGREE];
int flow_counter = 0;

#endif
