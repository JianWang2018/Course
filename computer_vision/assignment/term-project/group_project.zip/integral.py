import urllib, cStringIO
import numpy as np
import cv2

def integral_image(img):
    height, width = img.shape
    blank_image1 = np.zeros((height, width), int)
    blank_image2 = np.zeros((height, width), int)

    for m in xrange(height):
        for n in xrange(width):
            for z in xrange(m+1):
                blank_image1[m][n] += img[z][n]

    for m in xrange(height):
        for n in xrange(width):
            for z in xrange(n+1):
                blank_image2[m][n] += blank_image1[m][z]

    return blank_image2

img = np.array((
	[1, 1, 1, 1, 1, 1],
	[1, 1, 1, 1, 1, 1],
	[1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1],))

img = img.astype("uint8")
height, width = img.shape
img = integral_image(img)
print img[height-1][width-1]