import urllib, cStringIO
import numpy as np
import cv2

i = 1
for x in xrange(10):
    for j in xrange(10):
        file = str(x+1)+"/" + str(j+1) +".jpg"
        img = cv2.imread(file)
        img = cv2.pyrDown(img)
        img = cv2.pyrDown(img)
        cv2.imwrite( str(i) + ".jpg", img)
        i += 1