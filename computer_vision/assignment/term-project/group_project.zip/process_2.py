import urllib, cStringIO
import numpy as np
import cv2

i = 1
for x in xrange(10):
    file = "11/" + str(x+1) + ".jpg"
    img = cv2.imread(file)
    img = cv2.pyrDown(img)
    img = cv2.pyrDown(img)
    for m in xrange(5):
        for n in xrange(6):
            crop_img = img[m*23:(m+1)*23, n*28:(n+1)*28]
            cv2.imwrite(str(i) + ".jpg", crop_img)
            i += 1