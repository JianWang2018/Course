// JacobiMethod.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>

using namespace std;

void JacobiMethod(int N, double *A, double *b, double *x, int nMaxIterStep = 20)
{
	if (N < 2)
		return;
	
	double *xTemp = (double *)malloc(N * sizeof(double));
	int nStep = 0;

	while (nStep < nMaxIterStep)
	{
		++nStep;
		for (int i=0; i<N; ++i)
		{
			xTemp[i] = 0;
			for (int j=0; j<N; ++j)
			{
				if (j != i)
				{
					xTemp[i] += A[i*N+j]*x[j];
				}
			}
			xTemp[i] = (b[i] - xTemp[i])/A[i*N+i];
		}
		for (int i=0; i<N; ++i)
		{
			x[i] = xTemp[i];
		}
	}

	free(xTemp);
}

int _tmain(int argc, _TCHAR* argv[])
{
	int nMaxIterStep = 20;
	int N = -9291;
	while (N < 2)
	{
		if (N == -9291)
		{
			printf("Please Input a number to determine the size of Array or  input 0 to Exit: ");
			scanf("%d", &N);
		}
		else if (N != 0)
		{
			printf("Error Input! Please Input a number( bigger than 1) or  input 0 to Exit: ");
			scanf("%d", &N);
		}
		else//exit
			return 0;
	}
	//define and init Array
	double *A = (double *)calloc(N * N, sizeof(double));
	double *b = (double *)calloc(N, sizeof(double));
	double *x = (double *)calloc(N, sizeof(double));
	for (int i=0; i<N; ++i)
	{
		for(int j=0; j<N; ++j)
		{
			if (j == i)
				A[i*N+j] = 2;
			else if (j == i-1 || j == i+1)
				A[i*N+j] = -1;
		}
	}
	b[0] = 1;
	b[N-1] = 1;

	JacobiMethod(N, A, b, x, nMaxIterStep);

	printf("\nThe solution of x is:\n");
	for (int i=0; i<N; ++i)
	{
		printf("%0.8f   ", x[i]);
	}
	printf("\n");

	free(A);
	free(b);
	free(x);

	system("pause");

	return 0;
}

