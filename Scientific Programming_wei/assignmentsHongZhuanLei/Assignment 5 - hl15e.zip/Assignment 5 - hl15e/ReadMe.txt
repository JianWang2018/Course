====================================================================
			Array class 
=====================================================================

This program is built on Visual studio 2010 and includes two main files:
   1.  ArrayClass.h  
   2.  ArrayClass.cpp

ArrayClass.h
    this is a main header file, including all the declarations of members in a class called Array.

ArrayClass.cpp
    this is a main source file, including all the definitions of members in Array 
    and the main function which includes a routine to test all member functions in Array.


