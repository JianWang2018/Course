// CountWord.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <fstream>

using namespace std;

int SubCountWord(char *str, const char *delim)
{
	char *token = strtok(str, delim);
	int nCount = 0;
	while (token)
	{
		++nCount;
		token = strtok(NULL, delim);
	}
	return nCount;
}
bool CountWordFile(const char *strFilePath, int &nCount)
{
	nCount = 0;

	ifstream file(strFilePath, ios::in | ios::binary | ios::ate);
	if (!file.is_open())
		return false;

	streampos size = file.tellg();
	char *memblock = new char[size];
	file.seekg(0, ios::beg);
	file.read(memblock, size);
	file.close();

	nCount = SubCountWord(memblock, " \r\n\t");

	delete [] memblock;
	
	return true;
}
//
void CountWord()
{
	printf("Please input the full path name of the file (i.e. c:\\filename.txt):\n");

	char strFilePath[101];
	scanf("%100s", strFilePath);

	int nCount = 0;
	bool bRes = CountWordFile(strFilePath, nCount);

	if (bRes)
		printf("The number of word in this file is: %d\n", nCount);
	else
		printf("Cannot find this file!\n");
}
//
bool WriteFile(const char *strFilePath)
{
	ofstream file(strFilePath, ios::out | ios::binary | ios::app);
	if (!file.is_open())
		return false;

	int iSize = 10;
	float *A = (float *)malloc(iSize*iSize*sizeof(float));
	float *B = (float *)malloc(iSize*iSize*sizeof(float));
	
	for (int i=0; i<iSize; ++i)
	{
		for (int j=0; j<iSize; ++j)
		{
			A[i*iSize+j]= i+j+1.0;
			B[i*iSize+j]= 1.0/(i+j+1.0);
		}
	}

	file.write((char *)A, iSize*iSize*sizeof(float));
	file.write((char *)B, iSize*iSize*sizeof(float));
	file.close();

	free(A);
	free(B);

	return true;
}
//
void WriteDataFile()
{
	printf("Please input the full path name of the file you want to write into (i.e. c:\\filename.txt):\n");

	char strFilePath[101];
	scanf("%100s", strFilePath);

	bool bRes = WriteFile(strFilePath);

	if (bRes)
		printf("Data has been written into this file successfully!\n");
	else
		printf("Cannot find or create this file!\n");
}
//
bool ReadFile(const char *strFilePath)
{
	ifstream file(strFilePath, ios::in | ios::binary);
	if (!file.is_open())
		return false;

	int iSize = 10;
	float *A = new float[iSize*iSize];
	file.read((char *)A, iSize*iSize*sizeof(float));

	float *B = new float[iSize*iSize];
	file.read((char *)B, iSize*iSize*sizeof(float));
	file.close();

	float *C = (float *)malloc(iSize*iSize*sizeof(float));

	float fSum = 0.0;
	for (int i=0; i<iSize; ++i)
	{
		for (int j=0; j<iSize; ++j)
		{
			float fTemp = 0.0;
			for (int k=0; k<iSize; ++k)
			{
				fTemp += A[i*iSize+k] * B[k*iSize+j];
			}
			C[i*iSize+j]= fTemp;
			fSum += fTemp;
		}
	}
	fSum /= (iSize*iSize);
	
	printf("Please input the full path name of the file you want to write the report into (i.e. c:\\filename.txt):\n");

	char strReportFile[101];
	scanf("%100s", strReportFile);
	ofstream outFile(strReportFile, ios::out);
	if (!outFile.is_open())
		return false;

	outFile<<"The matrice A:"<<endl;
	for (int i=0; i<iSize; ++i)
	{
		for (int j=0; j<iSize; ++j)
		{
			outFile<<A[i*iSize+j]<<"  ";
		}
		outFile<<endl;
	}

	outFile<<endl<<"The matrice B:"<<endl;
	for (int i=0; i<iSize; ++i)
	{
		for (int j=0; j<iSize; ++j)
		{
			outFile<<B[i*iSize+j]<<"  ";
		}
		outFile<<endl;
	}

	outFile<<endl<<"The matrice C=AxB is:"<<endl;
	for (int i=0; i<iSize; ++i)
	{
		for (int j=0; j<iSize; ++j)
		{
			outFile<<C[i*iSize+j]<<"  ";
		}
		outFile<<endl;
	}

	delete [] A;
	delete [] B;
	free(C);

	outFile<<endl<<"The average of all elements of C is:"<<endl;
	outFile<<fSum<<endl;
	outFile.close();

	return true;
}
void ReadDataFile()
{
	printf("Please input the full path name of the file you want to read (i.e. c:\\filename.txt) :\n");

	char strFilePath[101];
	scanf("%100s", strFilePath);

	bool bRes = ReadFile(strFilePath);

	if (bRes)
		printf("Export result to your file successfully!\n");
	else
		printf("Cannot open this file!\n");
}

void MultiFunc()
{
	while (1)
	{
		printf("Please input your choose(1: CountWord  2: WriteFile  3: ReadFile  Others: exit): ");
		int index = 0;
		scanf("%d", &index);
		switch (index)
		{
		case 1:
			CountWord();
			break;
		case 2:
			WriteDataFile();
			break;
		case 3:
			ReadDataFile();
			break;
		default:
			return ;
		}
	}
}
//
int _tmain(int argc, _TCHAR* argv[])
{
	MultiFunc();
	
	system("pause");

	return 0;
}

