===============================================================================================================
    			Using Newton's method to find a root in function 'f(x)=0'
===============================================================================================================

Project:
       
    This is a vc++ console application named 'NewtonMethod.vcproj' built in visual studio 2010.net.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
Constructure: 

	1. A base class 'RealFunction' defined in RealFunction.h and RealFunction.cpp

	2. Tow derived class 'SinFunction' and 'MyFunction' defined in SinFunction.h & SinFunction.cpp
 		and MyFunction.h & MyFunction.cpp respectively.

	3. A test file named 'main.cpp' to test these codes.



///////////////////////////////////////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named NewtonMethod.pch and a precompiled types file named StdAfx.obj.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////